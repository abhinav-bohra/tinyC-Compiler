/* ------------------------------------------------------------------------
	COMPILERS LABORATORY (CS39003) | ASSIGNMENT 2 
	NAME	 : Abhinav Bohra
	ROLL NO. : 18CS30049
--------------------------------------------------------------------------*/
#include"toylib.h"
#include <stdio.h>
#include <stdlib.h>

int main()
{
 	int len1,len2,num=0;
	char choice;	
	float f;
	char string[]="Compliers Lab Assignment 1"; 
			       
	
        while(1){
		
		printf("\n------------- TOYLIB LIBRARY MENU ------------ \n");
                printf("\n1.Print String \n");
                printf("2.Read Hexadecimal Integer\n");
                printf("3.Print Hexadecimal Intger\n");
                printf("4.Read Float\n");
                printf("5.Print Float\n");
                printf("0.Exit\n");
                printf("\nEnter choice: ");
                scanf(" %c",&choice);
		if(choice < '0' || choice > '5'){
                        printf("\nInvalid choice, Please Re-enter choice.\n");
                        continue;
                }
                if(choice=='0')break;
                switch(choice){
                        case '1':len1 = printStringUpper(string);
                                 printf("\nThe length of printed string is: %d.\n",len1);
			         break;
                        case '2':if(readHexInteger(&num)==-1)   printf("\nInvalid number\n");
                                 else                           printf("\nHexadecimal Integer read successfully. It's decimal value is: %d\n",num);
			         break;
                        case '3':len2=printHexInteger(num);
			         if(len2==-1) printf("\nInvalid Hexadecimal number\n");
			         else         printf("\nThe number of characters printed:%d.\n",len2);
			         break;
                        case '4':if(readFloat(&f)==-1)  printf("\nInvalid number\n");
                                 else                   printf("\nFloat number read successfully. It's floating point value is: %f\n",f);
                                 break; 
			case '5':printFloat(f);
                                 break;                       
                }
        }
        return 0;
}
