/* ------------------------------------------------------------------------
	COMPILERS LABORATORY (CS39003) | ASSIGNMENT 2 
	NAME	 : Abhinav Bohra
	ROLL NO. : 18CS30049
--------------------------------------------------------------------------*/

#define MAX_BUFF_SIZE 100
#define BAD -1
#define GOOD 1

/* Function Definitions */

//Function to print a string of characters terminated by ‘\0’,where all the alphabetic characters are printed in uppercase

int printStringUpper (char *s){

    char buffer[MAX_BUFF_SIZE];
    int i=0,j=0;
    while(s[i]!='\0')
    {
        if(s[i]==92){                                           //Ignores a '\' character
           i++;
           continue;
        }
        if(s[i]>='a' && s[i]<='z') buffer[j]=s[i]-32;            //Converts a lowercase alphabet to upppercase alphabet
        else buffer[j]=s[i];                                     //Copy contents if not a lowercase alphabet

        j++;
        i++;
    }

    buffer[j]='\n';
    //display the string to output
    int num_bytes =j+1;
    __asm__ __volatile__ (
      "movl $1, %%eax\n\t"
      "movq $1, %%rdi\n\t"
      "syscall\n\t"
      :
      :"S"(buffer), "d"(num_bytes)
    );

    return j;                                                   //Return value is the number of characters printed (excluding the ‘\’ character).
}


//---------------------------------------------------------------------------------------------------------------------------------------------------
//Function to read a signed hexadecimal integer in ‘%x’ format, convert it to decimal, and pass the value through the pointer parameter.

int readHexInteger(int *n){

	char buffer[1];
	char hex[20];
	int length=0;                  //length of string
  	int sign_flag=0; 	       //sign_flag-: 0-> postive 1->negative
	int first_pass=0;

 	while(1)
  	{
	   	 __asm__ __volatile__ 
		    (
		      "syscall"
		      :
		      :"a"(0), "D"(0), "S"(buffer), "d"(1)
		    );

		  if(buffer[0]=='-' && first_pass==0) {
			sign_flag=1;
			continue;
		  }
	
		  first_pass=1; 
		  if(buffer[0]==' ' || buffer[0]=='\t'|| buffer[0]=='\n') break;
		  else if ((((int)buffer[0] <= '0' + 9 && (int)buffer[0] >= 0 + '0') ) || (buffer[0] >='A' && buffer[0] <='F')|| (buffer[0] >='a' && buffer[0] <='f') ) hex[length++]=buffer[0];	
		  else {*n=-1;return BAD;} //Implicit Validation of String : Return BAD if invalid character found
  	}

	//VALDITIY CHECKS
	//Check for invalid strings like - " "
	if( ( hex[0]==' '|| hex[0]=='\t'|| hex[0]=='\n') && length<=1){   
		
		*n=-1;
		return BAD;
	}
	//Check for invalid strings like - "-" 
	if(hex[0]=='-' && length<1){   
		
		*n=-1;
		return BAD;
	}

	//Handle Stack Smashing Error
	if(length > 20){

		*n=-1;
		return BAD;
	 }

   	 //Converting hexadecimal string stored in temp into decimal equivalent
   	 long long decimal = 0, base = 1;
   	 for(int i = length-1; i >= 0; i--)
   	 {
		if(hex[i] >= '0' && hex[i] <= '9')
		{
		    decimal += (hex[i] - 48) * base;
		    base *= 16;
		}
		else if(hex[i] >= 'A' && hex[i] <= 'F')
		{
		    decimal += (hex[i] - 55) * base;
			    base *= 16;
        	}
        	else if(hex[i] >= 'a' && hex[i] <= 'f')
        	{
        	    decimal += (hex[i] - 87) * base;
        	    base *= 16;
        	}
    	}

 	//Check if num is negative 
	decimal = (sign_flag  == 1) ? decimal*(-1) : decimal;
	//Store calculated decimal value in pointer
	*n=decimal;

	return GOOD;	//No errors, return GOOD
}

//---------------------------------------------------------------------------------------------------------------------------------------------------
//Function to print the (signed) decimal integer n in left-aligned hexadecimal form

int printHexInteger (int n){

	char hex[20];
	int i=0;
	int sign_flag=0;  

	if(n<0){			              //sign_flag-: 0-> postive 1->negative
		sign_flag=1;
		n=-n;
	}

	while(n!=0) 
	{   	 
		int temp  = 0;                        // Temporary variable to store remainder
		temp = n % 16;                        // Storing remainder in temp variable
		  
		// Check if temp < 10 
		if(temp < 10) hex[i++] = temp + 48; 
		else          hex[i++] = temp + 55; 
		    
		n = n/16; 
	} 

	if(sign_flag) hex[i++]='-';
	int k=i-1;
	int j=0;
	while(j<k){
		int temp=hex[j];
		hex[j]=hex[k];
		hex[k]=temp;
		j++;
		k--;	
	}

    hex[i]='\n';				     //display the string to output
    int num_bytes =i+1;
    __asm__ __volatile__ (
      "movl $1, %%eax\n\t"
      "movq $1, %%rdi\n\t"
      "syscall\n\t"
      :
      :"S"(hex), "d"(num_bytes)
    );

    return i;					    //On success, the function will return the number of characters printed,

}
//---------------------------------------------------------------------------------------------------------------------------------------------------
//Function to read a floating point number in ‘%f’ format

int readFloat (float *f){
  
  char buffer[1];
  char temp[20];
  int validity_flag=1;   				//1-> Valid Int 0-> Invalid Int	
  int length=0;
  
  while (1) {
   __asm__ __volatile__ ("syscall"::"a"(0), "D"(0), "S"(buffer), "d"(1)); 

    if(buffer[0]==' ' || buffer[0]=='\t' || buffer[0]=='\n') break;       
    else if ((((int)buffer[0] <= '0' + 9 && (int)buffer[0] >= 0 + '0') ) || buffer[0]=='-' || buffer[0]=='.') temp[length++]=buffer[0];             
    else validity_flag=0;
  }

  //VALDIITY CHECKS
  if(length > 12 || length == 0 ) 
  {
    *f=1;
    return BAD;
  } 

  if(validity_flag==0 || (temp[0]=='-' && length==1))
  {
    *f=1;
    return BAD;
  } 

  
  int p=1;
  int dec_flag=0;
  float num=0.0;
  int start_index = (temp[0]=='-')? 1:0;           //Add negative sign in front if number is negative

	  for(int i=start_index;i<length;i++)
	  {
		// printf("i:%d",i);
		if(temp[i]=='-') {*f=1;return BAD;}
		if(temp[i]=='.')
		{
		      if(dec_flag==0) dec_flag=1;
		      else {*f=1;return BAD;}
		      continue;
		}

		if(dec_flag)
		{
		      p*=10;
		      num+=((float)((int)temp[i]-'0'))/p;
		}
		else
		{
		      num*=10;        
		      num+=((int)temp[i]-'0');
		}     
	  }

  *f = (temp[0]=='-')? -num: num;
  return GOOD;
}

//---------------------------------------------------------------------------------------------------------------------------------------------------
//Function to print the floating point number f 

int printFloat (float f){

	char buffer[MAX_BUFF_SIZE];
	int i=0;
  	int count=0;
 	int num_bytes=0;

	  if(f==0) buffer[0]='0';
	  else 
	  {
	    	int negative=0;
	    	if(f<0) 
	    	{
		      buffer[0]='-';
		      count++;
		      negative=1;
		      f=-f;
		}   
	    
		int t = (int) f;
	   	while ( !( ( f - ((int)f) ) < 0.00001 || ( ((int)f) - f ) > 0.00001) ) //checking for equality in double      
	    	{
	    	  f*=10.0;
	    	  count++;      
	    	}
	   	 int decimal_index=count;
	  	 do
	    	 {
	      		count++;
	     		t=t/10;
	    	 }while(t!=0);
	    
	  	decimal_index = count - decimal_index + negative;	    	
		i=count+1;
	    	int int_f = (int)f;
	   	int remainder = 0;

	        while(count>=negative) 
	        {
	      		if (count==decimal_index)buffer[count--]='.'; 
		  	else 
		        {
				remainder=int_f%10;
				buffer[count--]=(char)(remainder+'0');
				int_f/=10.0;
		      	}
	        }
  	  }
	 
	  buffer[i]='0';
	  buffer[i+1]='\n';
	  num_bytes=i+2;
	  //display ouput string 
	  __asm__ __volatile__ 
	  (
	    "movl $1, %%eax \n\t"
	    "movq $1, %%rdi \n\t"
	    "syscall \n\t"
	    :
	    :"S"(buffer),"d"(num_bytes)
	  );
	  return i+1;
}
//---------------------------------------------------------------------------------------------------------------------------------------------------
