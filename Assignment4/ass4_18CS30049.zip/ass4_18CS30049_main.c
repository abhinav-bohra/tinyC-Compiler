/*-------------------------------------------------------------------
    Compilers Laboratory: CS39003 
    Assignment - 4: Parser for tinyC
    Abhinav Bohra | 18CS30049 
    Main File
--------------------------------------------------------------------*/
#include "y.tab.h"
#include <stdio.h>

extern int yyparse();
int main()
{
    yyparse();
    return 0;
}
