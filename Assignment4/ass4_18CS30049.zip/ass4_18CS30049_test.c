/*-------------------------------------------------------------------
    Compilers Laboratory: CS39003 
    Assignment - 4: Parser for tinyC
    Abhinav Bohra | 18CS30049 | Testing File
--------------------------------------------------------------------*/
//  PLEASE NOTE : The following C code is for testing of bison specifictions

//Testing function protoyping
int getAnswer();
double someFunction(int a, int x);
void checkAnswer(float f, double g, int q);

int main(){

	//Testing variable declarations of different data tyes
 	int a=4;
	int i = 89;	
	float f1 = 3425.896 ;
	float f2 = 12E-2 ; 	
 	float f3 = 55e+92 ; 	
 	double array1[10];
	int array2[]={2,3,4,5,1,7,2,4};
	char c='y';
 	char s[] = "This is a test for string literal \n \t";
	
	//Testing for loop
	for(int i=0;i<n;i++)
	{
		//Testing nested loops
		for(int j=0;j<m;j++)
		{
			dfs[i]= 1 + dfs[j-1];
		}
	}

	int j=0;
	float f=12.5;

	//Testing while loop
	while(i <5 && i >0)
	{
		int array[6];
		f++;
		f--;
		f/=2;
		f*=4;
		function_call();
		int x = sizeof(char);
		if(f==0) break;
		
		// Testing loop not encosed within parentheses
		for(int i=0;i<4;i++) array[i]++; 
	}

	//Testing function calls
	int y = getAnswer();
	double val = someFunction(3,4);
	checkAnswer(2.1,-3.554, y);
	bubble_sort(&a,5);

  return 0;
} 

//Testing function definitions
double someFunction(int a, int x)
{
	int a[5];	
	int b[]={2,3,4,5};
        float c = b[3]-a;

	//Testing jump statements
	if(c > 0) return 6;
	else      return 5;

	//Testing different operators & jump statements

	if(x&1==0) return x*c;
	else if(~x==0) return x/2;
	
	if(x%1==0) return x*a[2];	
	else if(x&1==0) return x*3;
	
}

int bubble_sort(int a[],int n)
{
	int i,j,flag,temp;
	for(i=0;i<n-1;i++)
	{
		flag=0;
		for(j=0;j<n-i-1;j++)
			if(a[j]>a[j+1])
			{
				flag=1;
				temp=a[j];
				a[j]=a[j+1];
				a[j+1]=temp;
			}
		if(flag==0)
			break;
	}
}

void checkAnswer(float f, double g, int q){


	int c=4;
	int m = -3;	
	c = (int) f;
	m = (int) g;

	if(m >=c && f!=g) m++;
	else
	{
		int array[5];	
		for(int i=0;i<4;i++) array[i]++;	
	} 
	
	//Testing optional return value
	return;

}

int getAnswer(){

	int i;
	i=10;
	if(i>0 || i<=34) return 1;
	else return 0;
}

