/*-------------------------------------------------------------------
    Compilers Laboratory: CS39003 | Assignment - 3: Lexer for tinyC
    Abhinav Bohra | 18CS30049 | Testing File
--------------------------------------------------------------------*/
//  PLEASE NOTE : The following C code is syntactically INCORRECT. The given arrangement is done to make testing of flex specifictions easy

#include<stdio.h>

int main(){


	//Test 1 : Keywords
 	break  case char continue default do double else extern float for goto 
	if int long return short sizeof static struct switch typedef union void while

	//Test 2 : Identifiers and Constants
	int i = 89;	
	float f1 = 3425.896 ;
	float f2 = 12E-2 ; 	
 	float f3 = 55e+92 ; 	
 	double array[10];
	char c='y';
 	string s = "This is a test for string literal \n \t";

	// Test 3 : Punctuators
	[ ++ / ? = , ] ( { } . -> * + - ~ ! % << >> < > <= >= : ; ...
	*= /= %= += -= <<= # -- ) & == >>= != &= ^ | ^= && || |=

	//Test 4 : Comments

	/* Test for multi  line comment */*/
	// Test for single line comment 

	//Testing of some syntactically correct c code

	for(int i=0;i<n;i++){
	{
		for(int j=0;j<m;j++)
		{
			dfs[i][j]= 1 + dfs[i-1][j-1];
		}
	}

	int j=0;
	float f=12.5;
	while(i <5 && i >0){
	
		f++;
		f--;
		f/=2;
		f*=4;
		function_call();
		int x = sizeof(char);
		if(f==0) break;

	}


	return 0;
}

