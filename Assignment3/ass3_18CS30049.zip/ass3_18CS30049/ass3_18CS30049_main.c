/*-------------------------------------------
    Compilers Laboratory: CS39003
    Assignment - 3: Lexer for tinyC
    Abhinav Bohra | 18CS30049
    Main Function (Lex Driver)
--------------------------------------------*/
#include <stdio.h>
#include "ass3_18CS30049_header.h"

extern int yylex ();
extern char* yytext;
int main() 
{ 
	extern FILE *yyin; 
	yyin = fopen("ass3_18CS30049_test.c","r");

	int token=0;
	while (token = yylex()) 
	{
		switch (token) 
		{
		    case IDENTIFIER:           printf("< IDENTIFIER, %d, %s >\n",token,yytext);break;
		    case INTEGER_CONSTANT:     printf("< INTEGER_CONSTANT, %d, %s >\n",token,yytext);break; 
		    case FLOATING_CONSTANT:    printf("< FLOATING_CONSTANT, %d, %s >\n",token,yytext);break; 
		    case CHARACTER_CONSTANT:   printf("< CHARACTER_CONSTANT, %d, %s >\n",token,yytext);break; 
		    case STRING_LITERAL:       printf("< STRING_LITERAL, %d, %s >\n",token,yytext);break; 
		    case KEYWORD:	       printf("< KEYWORD, %d, %s >\n",token,yytext);break;     
		    case PUNCTUATOR:	       printf("< PUNCTUATOR, %d, %s >\n",token,yytext);break; 
		    case SINGLE_LINE_COMMENT:  printf("< SINGLE_LINE_COMMENT, %d, %s >\n",token,yytext);break;     
		    case MULTI_LINE_COMMENT:   printf("< MULTI_LINE_COMMENT, %d, %s >\n",token,yytext);break; 
		    default:		       break;	    	
        	}	

    }
	fclose(yyin);
	return 0;
}

