#ifndef _ASS3_18CS30049_HEADER_H
	
	#define _ASS3_18CS30049_HEADER_H

	#define KEYWORD 			1
	#define IDENTIFIER 			2
	#define INTEGER_CONSTANT		3		
	#define FLOATING_CONSTANT		4		
	#define CHARACTER_CONSTANT 		5	
	#define STRING_LITERAL 			6
	#define PUNCTUATOR                      7
	#define MULTI_LINE_COMMENT		8	
	#define SINGLE_LINE_COMMENT		9

#endif
